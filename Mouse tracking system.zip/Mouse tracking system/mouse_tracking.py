import sys
import os
import time
import ctypes
import threading

# Get the username of the current user
username = os.getlogin()

# Get the directory of the script
script_dir = os.path.dirname(os.path.abspath(__file__))

# Create a directory to store log files if it doesn't exist
log_dir = os.path.join(os.path.dirname(sys.argv[0]), "activity_logs")
os.makedirs(log_dir, exist_ok=True)

# Get the current date
current_date = time.strftime("%Y-%m-%d")

# Define the log file paths
activity_log_file = os.path.join(log_dir, f"{current_date}_activity_log.txt")
lock_log_file = os.path.join(log_dir, f"{current_date}_lock_log.txt")

# Shared variable to control thread termination
running = True

# Function to log activity
def log_activity(activity, file_path, create_new=False):
    mode = 'a' if not create_new else 'w'
    with open(file_path, mode) as f:
        f.write(activity + "\n")
        print(f"Activity logged: {activity}")  # Print for debugging purposes

# Function to check system lock and unlock
def check_lock_unlock():
    user32 = ctypes.windll.User32
    if user32.GetForegroundWindow() == 0:
        return True  # System locked
    else:
        return False  # System unlocked

# Function to handle activity logging
def handle_activity_logging():
    global running
    if not os.path.exists(activity_log_file):
        log_activity("Starting activity log...", activity_log_file, create_new=True)
    
    last_activity_time = time.time()
    while running:
        if time.time() - last_activity_time > 15 * 60:
            # Log no activity found
            activity = f"{time.strftime('%Y-%m-%d %H:%M:%S')} - No activity found for {username}"
            log_activity(activity, activity_log_file)
            # Reset last activity time
            last_activity_time = time.time()
        
        time.sleep(60)  # Check every minute

# Function to handle system lock/unlock logging
def handle_lock_unlock_logging():
    global running
    is_locked = False
    while running:
        # Check system lock and unlock
        if check_lock_unlock():
            if not is_locked:
                activity = f"{time.strftime('%Y-%m-%d %H:%M:%S')} - System locked for {username}"
                log_activity(activity, lock_log_file)
                is_locked = True
        else:
            if is_locked:
                activity = f"{time.strftime('%Y-%m-%d %H:%M:%S')} - System unlocked for {username}"
                log_activity(activity, lock_log_file)
                is_locked = False
        
        time.sleep(5)  # Check every 5 seconds

# Start activity and lock/unlock logging threads
handle_activity_logging_thread = threading.Thread(target=handle_activity_logging)
handle_lock_unlock_logging_thread = threading.Thread(target=handle_lock_unlock_logging)

handle_activity_logging_thread.start()
handle_lock_unlock_logging_thread.start()

# Wait for user input to exit
try:
    input("Press Enter to exit...\n")
    running = False
    handle_activity_logging_thread.join()
    handle_lock_unlock_logging_thread.join()
except KeyboardInterrupt:
    print("\nStopping the script...")
    running = False
    handle_activity_logging_thread.join()
    handle_lock_unlock_logging_thread.join()
